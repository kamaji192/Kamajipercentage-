// Function to calculate the percentage
function calculatePercentage(part, whole) {
    if (whole === 0) {
        return 'Whole value cannot be zero.';
    }
    if (part > whole) {
        return 'The part value cannot be greater than the whole value.';
    }
    return ((part / whole) * 100).toFixed(2) + '%';
}

// Add event listener to the "Calculate Percentage" button
document.getElementById('calculateBtn').addEventListener('click', function() {
    // Get the part and whole values from the input fields
    const part = parseFloat(document.getElementById('part').value);
    const whole = parseFloat(document.getElementById('whole').value);

    // Check if the values are valid numbers
    if (isNaN(part) || isNaN(whole)) {
        alert('Please enter valid numbers for both part and whole.');
        return;
    }

    // Calculate the percentage
    const result = calculatePercentage(part, whole);

    // Display the result and change text color to orange (#ff9800)
    const resultElement = document.getElementById('percentageResult');
    resultElement.innerText = result;
    resultElement.style.color = '#ff9800';  // Change result text color to orange
});

// Add event listener to the "Reset" button
document.getElementById('resetBtn').addEventListener('click', function() {
    // Clear the input fields and result
    document.getElementById('part').value = '';
    document.getElementById('whole').value = '';
    document.getElementById('percentageResult').innerText = 'The percentage will appear here.';
    document.getElementById('percentageResult').style.color = 'white';  // Reset result text color
});
